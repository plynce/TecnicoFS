#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <ctype.h>
#include <pthread.h>
#include <time.h>
#include "fs/ThreadsSynch.h"

#define MAX_COMMANDS 150000
#define MAX_INPUT_SIZE 100

char inputCommands[MAX_COMMANDS][MAX_INPUT_SIZE];
int headQueue = 0;
int numberCommands = 0;
double duration;
pthread_mutex_t trinco;
pthread_rwlock_t trinco_rw;

int insertCommand(char* data) {
    if(numberCommands != MAX_COMMANDS) {
        strcpy(inputCommands[numberCommands++], data);
        return 1;
    }
    return 0;
}

char* removeCommand() {
    if(numberCommands > 0){
        numberCommands--;
        return inputCommands[headQueue++];  
    }
    return NULL;
}

void errorParse(){
    fprintf(stderr, "Error: command invalid\n");
    exit(EXIT_FAILURE);
}

void processInput(char * ficheiro){
    char line[MAX_INPUT_SIZE];
    FILE * fp;
    fp = fopen(ficheiro, "r");

    /* break loop with ^Z or ^D */
    while (fgets(line, sizeof(line)/sizeof(char), fp)) {
        char token, type;
        char name[MAX_INPUT_SIZE];

        int numTokens = sscanf(line, "%c %s %c", &token, name, &type);

        /* perform minimal validation */
        if (numTokens < 1) {
            continue;
        }
        switch (token) {
            case 'c':
                if(numTokens != 3)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case 'l':
                if(numTokens != 2)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case 'd':
                if(numTokens != 2)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case '#':
                break;
            
            default: { /* error */
                errorParse();
            }
        }
    }
    fclose(fp);
}

void applyCommands(){
    clock_t end, beg = clock();

    while (numberCommands > 0){
    
        const char* command = removeCommand();
        if (command == NULL){
            continue;
        }

        char token, type;
        char name[MAX_INPUT_SIZE];
        int numTokens = sscanf(command, "%c %s %c", &token, name, &type);

        if (numTokens < 2) {
            fprintf(stderr, "Error: invalid command in Queue\n");
            printf("Linha 108\n");
            exit(EXIT_FAILURE);
        }


        int searchResult;
        switch (token) {
            case 'c':
                switch (type) {
                    case 'f':
                        printf("Create file: %s\n", name);
                        create(name, T_FILE);
                        break;
                    case 'd':
                        printf("Create directory: %s\n", name);
                        create(name, T_DIRECTORY);
                        break;
                    default:
                        fprintf(stderr, "Error: invalid node type\n");
                        exit(EXIT_FAILURE);
                }
                break;
            case 'l': 
                searchResult = lookup(name);
                if (searchResult >= 0)
                    printf("Search: %s found\n", name);
                else
                    printf("Search: %s not found\n", name);
                break;
            case 'd':
                printf("Delete: %s\n", name);
                delete(name);
                break;
            default: { /* error */
                fprintf(stderr, "Error: command to apply\n");
                exit(EXIT_FAILURE);
            }
        }
    
    }
    end = clock();
    duration = ((double)(end - beg))/CLOCKS_PER_SEC;
}

void * applyCommands_mutex(){

    while (numberCommands > 0){
        
        pthread_mutex_lock(&trinco);
        const char* command = removeCommand();
        pthread_mutex_unlock(&trinco);
        if (command == NULL){
            continue;
        }

        char token, type;
        char name[MAX_INPUT_SIZE];
        pthread_mutex_lock(&trinco);
        int numTokens = sscanf(command, "%c %s %c", &token, name, &type);
        if (numTokens < 2) {
            fprintf(stderr, "Error: invalid command in Queue\n");
            exit(EXIT_FAILURE);
        }
        pthread_mutex_unlock(&trinco);

        int searchResult;
        pthread_mutex_lock(&trinco);
        switch (token) {
            case 'c':
                switch (type) {
                    case 'f':
                        printf("Create file: %s\n", name);
                        create(name, T_FILE);
                        break;
                    case 'd':
                        printf("Create directory: %s\n", name);
                        create(name, T_DIRECTORY);
                        break;
                    default:
                        fprintf(stderr, "Error: invalid node type\n");
                        exit(EXIT_FAILURE);
                }
                break;
            case 'l': 
                searchResult = lookup(name);
                if (searchResult >= 0)
                    printf("Search: %s found\n", name);
                else
                    printf("Search: %s not found\n", name);
                break;
            case 'd':
                printf("Delete: %s\n", name);
                delete(name);
                break;
            default: { /* error */
                fprintf(stderr, "Error: command to apply\n");
                exit(EXIT_FAILURE);
            }
        }
        pthread_mutex_unlock(&trinco);
    } 

    return NULL;
}

void * applyCommands_rwlock(){
    
    if (pthread_rwlock_init(&trinco_rw, NULL) != 0){
        fprintf(stderr, "Erro na inicializacao do rwlock.\n");
        exit(EXIT_FAILURE);
    }

    while (numberCommands > 0){
        pthread_mutex_lock(&trinco);
        const char* command = removeCommand();
        pthread_mutex_unlock(&trinco);
        if (command == NULL){
            continue;
        }

        char token, type;
        char name[MAX_INPUT_SIZE];
        pthread_rwlock_rdlock(&trinco_rw);
        int numTokens = sscanf(command, "%c %s %c", &token, name, &type);
        pthread_rwlock_unlock(&trinco_rw);
        if (numTokens < 2) {
            fprintf(stderr, "Error: invalid command in Queue\n");
            exit(EXIT_FAILURE);
        }

        int searchResult;
        pthread_rwlock_rdlock(&trinco_rw);
        switch (token) {
            case 'c':
                switch (type) {
                    case 'f':
                        printf("Create file: %s\n", name);
                        create(name, T_FILE);
                        pthread_rwlock_unlock(&trinco_rw);
                        break;
                    case 'd':
                        printf("Create directory: %s\n", name);
                        create(name, T_DIRECTORY);
                        pthread_rwlock_unlock(&trinco_rw);
                        break;
                    default:
                        fprintf(stderr, "Error: invalid node type\n");
                        exit(EXIT_FAILURE);
                }
                break;
            case 'l': 
                searchResult = lookup(name);
                if (searchResult >= 0)
                    printf("Search: %s found\n", name);
                else
                    printf("Search: %s not found\n", name);
                pthread_rwlock_unlock(&trinco_rw);
                break;
            case 'd':
                pthread_rwlock_unlock(&trinco_rw);
                pthread_mutex_lock(&trinco);
                printf("Delete: %s\n", name);
                delete(name);
                pthread_mutex_unlock(&trinco);
                break;
            default: { /* error */
                fprintf(stderr, "Error: command to apply\n");
                exit(EXIT_FAILURE);
            }
        }
    } 
    if (pthread_rwlock_destroy(&trinco_rw) != 0){
        fprintf(stderr, "Erro na destruicao do rwlock.\n");
        exit(EXIT_FAILURE);
    }

    return NULL;
}

void applyCommands_sync(int numThreads, char * synchstrategy){
    clock_t beg, end;
    void * (*fun_ptr)(void*);
    int i = 0;
    pthread_t tid[numThreads];

    if (!strcmp(synchstrategy, "mutex"))
        fun_ptr = &applyCommands_mutex;
        
    else 
        fun_ptr = &applyCommands_rwlock;

    if (pthread_mutex_init(&trinco, NULL) != 0){
        fprintf(stderr, "Erro na inicializacao do mutex.\n");
        exit(EXIT_FAILURE);
    }
        
    beg = clock();
    for (; i < numThreads; i++)
        if (pthread_create(&tid[i], NULL, fun_ptr, NULL) != 0){
            fprintf(stderr, "Erro na criacao das tarefas.\n");
            exit(EXIT_FAILURE);
        }

    for (i = 0; i < numThreads; i++){
        if (pthread_join(tid[i], NULL) != 0){
            fprintf(stderr, "Erro na terminacao das tarefas.\n");
            exit(EXIT_FAILURE);
        }
    }
    end = clock();

    duration = ((double)(end - beg))/CLOCKS_PER_SEC;

    if (pthread_mutex_destroy(&trinco) != 0){
        fprintf(stderr, "Erro na destruicao do mutex.\n");
        exit(EXIT_FAILURE);
    }
}

int main(int argc, char* argv[]) {
    /* Arguments management */
    char * inputfile = argv[1];
    char * outputfile = argv[2];
    int numThreads = atoi(argv[3]);
    char * synchstrategy = argv[4];
    
    FILE * fp;

    /* init filesystem */
    init_fs();

    /* process input and print tree */
    processInput(inputfile);
    
    /* Aplly commands with the number of threads and synchstrategy wanted */
    if (TecnicoFS_sync(numThreads, synchstrategy))
        applyCommands_sync(numThreads, synchstrategy);
    else
        applyCommands();

    /* Prints TecnicoFS duration in seconds */
    printTime(duration);

    /* Print fs tree to the output file */
    fp = fopen(outputfile, "w");
    print_tecnicofs_tree(fp);
    fclose(fp);

    /* release allocated memory */
    pthread_mutex_destroy(&trinco);
    pthread_rwlock_destroy(&trinco_rw);
    destroy_fs();
    exit(EXIT_SUCCESS);
}
