#ifndef TS_H
#define TS_H
#include "operations.h"

void printTime(double duration);
int TecnicoFS_sync(int numThreads, char * synchstrategy);

#endif /* TS_H */