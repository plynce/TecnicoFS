#include "ThreadsSynch.h"
#include <pthread.h>
#include <stdio.h>
#include <string.h>

void printTime(double duration){
    printf("TecnicoFS completed in %0.4f seconds.\n", duration);
}

int TecnicoFS_sync(int numThreads, char * synchstrategy){
    if (!strcmp(synchstrategy, "nosync"))
        if (numThreads == 1)
            return 0;
        else{
            fprintf(stderr,"Perigoso executar tarefas sem sincronizacao!\n");
            exit(EXIT_FAILURE);
        }
    else if (!strcmp(synchstrategy, "mutex"))
        if (numThreads > 1)
            return 1;
        else{
            fprintf(stderr,"Execucao com mutex deve incluir mais do que uma tarefa!\n");
            exit(EXIT_FAILURE);
        }
    else if (!strcmp(synchstrategy, "rwlock"))
        if (numThreads > 1)
            return 1;
        else{
            fprintf(stderr, "Execucao com rwlock deve incluir mais do que uma tarefa!\n");
            exit(EXIT_FAILURE);
        }
    else {
        fprintf(stderr, "Estrategia de sincronizacao invalida!\n");
        exit(EXIT_FAILURE);
    }
}
